import { z } from "zod";

// Bot connection status
export type BotStatus = "disconnected" | "connecting" | "connected" | "error";

// Bot configuration for connecting to a server
export const botConfigSchema = z.object({
  host: z.string().min(1, "Server address is required"),
  port: z.number().min(1).max(65535).default(25565),
  username: z.string().min(1, "Username is required").max(16),
  version: z.string().optional(),
});

export type BotConfig = z.infer<typeof botConfigSchema>;

// Bot state information
export interface BotState {
  status: BotStatus;
  health: number;
  food: number;
  position: { x: number; y: number; z: number } | null;
  gameMode: string | null;
  dimension: string | null;
  serverInfo: {
    host: string;
    port: number;
  } | null;
  connectedAt: number | null;
  error: string | null;
}

// Chat message structure
export interface ChatMessage {
  id: string;
  timestamp: number;
  type: "chat" | "system" | "whisper" | "action" | "bot";
  username: string | null;
  content: string;
}

// Bot command types
export type BotCommandType = 
  | "move_forward" 
  | "move_back" 
  | "move_left" 
  | "move_right"
  | "jump"
  | "sneak"
  | "sprint"
  | "stop"
  | "attack"
  | "use"
  | "chat"
  | "look_at"
  | "disconnect";

export interface BotCommand {
  type: BotCommandType;
  payload?: string | { x: number; y: number; z: number };
}

// WebSocket message types
export type WSMessageType = 
  | "bot_state" 
  | "chat_message" 
  | "command" 
  | "connect" 
  | "disconnect"
  | "error"
  | "chat_history"
  | "clear_chat";

export interface WSMessage {
  type: WSMessageType;
  payload: unknown;
}

// API response types
export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
}
