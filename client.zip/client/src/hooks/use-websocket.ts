import { useEffect, useRef, useState, useCallback } from "react";
import type { BotState, ChatMessage, WSMessage } from "@shared/schema";

interface UseWebSocketReturn {
  isConnected: boolean;
  botState: BotState;
  chatMessages: ChatMessage[];
  sendCommand: (type: string, payload?: unknown) => void;
  connect: (config: { host: string; port: number; username: string; version?: string }) => void;
  disconnect: () => void;
  sendChat: (message: string) => void;
  clearChat: () => void;
}

const initialBotState: BotState = {
  status: "disconnected",
  health: 20,
  food: 20,
  position: null,
  gameMode: null,
  dimension: null,
  serverInfo: null,
  connectedAt: null,
  error: null,
};

export function useWebSocket(): UseWebSocketReturn {
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const mountedRef = useRef(true);
  const [isConnected, setIsConnected] = useState(false);
  const [botState, setBotState] = useState<BotState>(initialBotState);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);

  const cleanupSocket = useCallback(() => {
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }
    if (wsRef.current) {
      wsRef.current.onopen = null;
      wsRef.current.onclose = null;
      wsRef.current.onerror = null;
      wsRef.current.onmessage = null;
      if (wsRef.current.readyState === WebSocket.OPEN || wsRef.current.readyState === WebSocket.CONNECTING) {
        wsRef.current.close();
      }
      wsRef.current = null;
    }
  }, []);

  const connectWebSocket = useCallback(() => {
    if (!mountedRef.current) return;
    if (wsRef.current?.readyState === WebSocket.OPEN || wsRef.current?.readyState === WebSocket.CONNECTING) {
      return;
    }

    cleanupSocket();

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    try {
      const socket = new WebSocket(wsUrl);
      wsRef.current = socket;

      socket.onopen = () => {
        if (!mountedRef.current) return;
        setIsConnected(true);
      };

      socket.onclose = () => {
        if (!mountedRef.current) return;
        setIsConnected(false);
        wsRef.current = null;
        
        reconnectTimeoutRef.current = setTimeout(() => {
          if (mountedRef.current) {
            connectWebSocket();
          }
        }, 3000);
      };

      socket.onerror = () => {
        if (socket.readyState !== WebSocket.CLOSED) {
          socket.close();
        }
      };

      socket.onmessage = (event) => {
        if (!mountedRef.current) return;
        try {
          const message: WSMessage = JSON.parse(event.data);
          
          switch (message.type) {
            case "bot_state":
              setBotState(message.payload as BotState);
              break;
            case "chat_message":
              setChatMessages((prev) => [...prev.slice(-199), message.payload as ChatMessage]);
              break;
            case "chat_history":
              setChatMessages(message.payload as ChatMessage[]);
              break;
            case "error":
              setBotState((prev) => ({
                ...prev,
                status: "error",
                error: message.payload as string,
              }));
              break;
          }
        } catch {
          console.error("Failed to parse WebSocket message");
        }
      };
    } catch (error) {
      console.error("Failed to create WebSocket:", error);
      reconnectTimeoutRef.current = setTimeout(() => {
        if (mountedRef.current) {
          connectWebSocket();
        }
      }, 3000);
    }
  }, [cleanupSocket]);

  useEffect(() => {
    mountedRef.current = true;
    connectWebSocket();

    return () => {
      mountedRef.current = false;
      cleanupSocket();
    };
  }, [connectWebSocket, cleanupSocket]);

  const sendMessage = useCallback((message: WSMessage) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(message));
    }
  }, []);

  const sendCommand = useCallback((type: string, payload?: unknown) => {
    sendMessage({ type: "command", payload: { type, payload } });
  }, [sendMessage]);

  const connect = useCallback((config: { host: string; port: number; username: string; version?: string }) => {
    sendMessage({ type: "connect", payload: config });
  }, [sendMessage]);

  const disconnect = useCallback(() => {
    sendMessage({ type: "disconnect", payload: null });
  }, [sendMessage]);

  const sendChat = useCallback((message: string) => {
    sendCommand("chat", message);
  }, [sendCommand]);

  const clearChat = useCallback(() => {
    sendMessage({ type: "clear_chat" as WSMessage["type"], payload: null });
  }, [sendMessage]);

  return {
    isConnected,
    botState,
    chatMessages,
    sendCommand,
    connect,
    disconnect,
    sendChat,
    clearChat,
  };
}
