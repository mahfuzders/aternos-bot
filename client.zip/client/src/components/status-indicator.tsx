import { cn } from "@/lib/utils";
import type { BotStatus } from "@shared/schema";

interface StatusIndicatorProps {
  status: BotStatus;
  showLabel?: boolean;
  size?: "sm" | "md" | "lg";
}

const statusConfig: Record<BotStatus, { color: string; label: string; pulse: boolean }> = {
  connected: { color: "bg-status-online", label: "Connected", pulse: true },
  connecting: { color: "bg-status-away", label: "Connecting", pulse: true },
  disconnected: { color: "bg-status-offline", label: "Disconnected", pulse: false },
  error: { color: "bg-status-busy", label: "Error", pulse: false },
};

const sizeMap = {
  sm: "h-2 w-2",
  md: "h-3 w-3",
  lg: "h-4 w-4",
};

export function StatusIndicator({ status, showLabel = false, size = "md" }: StatusIndicatorProps) {
  const config = statusConfig[status];

  return (
    <div className="flex items-center gap-2">
      <span className="relative flex">
        <span
          className={cn(
            "rounded-full",
            sizeMap[size],
            config.color,
            config.pulse && "animate-pulse"
          )}
          data-testid={`status-indicator-${status}`}
        />
        {config.pulse && (
          <span
            className={cn(
              "absolute inset-0 rounded-full opacity-75 animate-ping",
              config.color
            )}
          />
        )}
      </span>
      {showLabel && (
        <span
          className={cn(
            "text-sm font-medium",
            status === "connected" && "text-status-online",
            status === "connecting" && "text-status-away",
            status === "disconnected" && "text-muted-foreground",
            status === "error" && "text-status-busy"
          )}
          data-testid="text-status-label"
        >
          {config.label}
        </span>
      )}
    </div>
  );
}
