import { 
  ArrowUp, 
  ArrowDown, 
  ArrowLeft, 
  ArrowRight, 
  ArrowUpFromDot,
  Footprints,
  Zap,
  Hand,
  Sword,
  MousePointerClick,
  Gamepad2,
  AlertCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import type { BotCommandType, BotStatus } from "@shared/schema";

interface CommandPanelProps {
  status: BotStatus;
  onCommand: (command: BotCommandType) => void;
}

const movementCommands = [
  { type: "move_forward" as BotCommandType, icon: ArrowUp, label: "Forward", shortcut: "W" },
  { type: "move_back" as BotCommandType, icon: ArrowDown, label: "Back", shortcut: "S" },
  { type: "move_left" as BotCommandType, icon: ArrowLeft, label: "Left", shortcut: "A" },
  { type: "move_right" as BotCommandType, icon: ArrowRight, label: "Right", shortcut: "D" },
];

const actionCommands = [
  { type: "jump" as BotCommandType, icon: ArrowUpFromDot, label: "Jump" },
  { type: "sneak" as BotCommandType, icon: Footprints, label: "Sneak" },
  { type: "sprint" as BotCommandType, icon: Zap, label: "Sprint" },
  { type: "stop" as BotCommandType, icon: Hand, label: "Stop" },
];

const combatCommands = [
  { type: "attack" as BotCommandType, icon: Sword, label: "Attack" },
  { type: "use" as BotCommandType, icon: MousePointerClick, label: "Use Item" },
];

export function CommandPanel({ status, onCommand }: CommandPanelProps) {
  const isDisabled = status !== "connected";

  return (
    <Card>
      <CardHeader className="pb-4">
        <CardTitle className="text-lg font-semibold flex items-center gap-2">
          <Gamepad2 className="h-5 w-5" />
          Bot Controls
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <p className="text-xs text-muted-foreground mb-3 font-medium uppercase tracking-wide">Movement</p>
          <div className="grid grid-cols-4 gap-2">
            {movementCommands.map((cmd) => (
              <Tooltip key={cmd.type}>
                <TooltipTrigger asChild>
                  <Button
                    variant="secondary"
                    size="default"
                    disabled={isDisabled}
                    onClick={() => onCommand(cmd.type)}
                    data-testid={`button-${cmd.type.replace(/_/g, "-")}`}
                  >
                    <cmd.icon className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{cmd.label}</p>
                </TooltipContent>
              </Tooltip>
            ))}
          </div>
        </div>

        <div>
          <p className="text-xs text-muted-foreground mb-3 font-medium uppercase tracking-wide">Actions</p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {actionCommands.map((cmd) => (
              <Button
                key={cmd.type}
                variant="secondary"
                size="default"
                disabled={isDisabled}
                onClick={() => onCommand(cmd.type)}
                data-testid={`button-${cmd.type}`}
              >
                <cmd.icon className="h-4 w-4 mr-2" />
                <span className="text-xs">{cmd.label}</span>
              </Button>
            ))}
          </div>
        </div>

        <div>
          <p className="text-xs text-muted-foreground mb-3 font-medium uppercase tracking-wide">Combat</p>
          <div className="grid grid-cols-2 gap-2">
            {combatCommands.map((cmd) => (
              <Button
                key={cmd.type}
                variant="secondary"
                size="default"
                disabled={isDisabled}
                onClick={() => onCommand(cmd.type)}
                data-testid={`button-${cmd.type}`}
              >
                <cmd.icon className="h-4 w-4 mr-2" />
                {cmd.label}
              </Button>
            ))}
          </div>
        </div>

        {isDisabled && (
          <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground pt-2">
            <AlertCircle className="h-4 w-4" />
            <span data-testid="text-controls-disabled">Connect to a server to use controls</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
