import { useEffect, useState } from "react";
import { Heart, Drumstick, MapPin, Gamepad2, Globe, Clock, AlertCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { StatusIndicator } from "@/components/status-indicator";
import { Skeleton } from "@/components/ui/skeleton";
import type { BotState } from "@shared/schema";

interface BotStatsProps {
  state: BotState;
}

function formatUptime(connectedAt: number | null): string {
  if (!connectedAt) return "00:00:00";
  
  const elapsed = Math.floor((Date.now() - connectedAt) / 1000);
  const hours = Math.floor(elapsed / 3600);
  const minutes = Math.floor((elapsed % 3600) / 60);
  const seconds = elapsed % 60;
  
  return `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
}

function formatPosition(position: { x: number; y: number; z: number } | null): string {
  if (!position) return "Unknown";
  return `${Math.floor(position.x)}, ${Math.floor(position.y)}, ${Math.floor(position.z)}`;
}

function formatDimension(dimension: string | null): string {
  if (!dimension) return "Unknown";
  const name = dimension.replace("minecraft:", "").replace(/_/g, " ");
  return name.charAt(0).toUpperCase() + name.slice(1);
}

export function BotStats({ state }: BotStatsProps) {
  const [uptime, setUptime] = useState("00:00:00");
  const healthPercent = (state.health / 20) * 100;
  const foodPercent = (state.food / 20) * 100;
  const isConnected = state.status === "connected";
  const isConnecting = state.status === "connecting";

  useEffect(() => {
    if (!state.connectedAt) {
      setUptime("00:00:00");
      return;
    }

    const interval = setInterval(() => {
      setUptime(formatUptime(state.connectedAt));
    }, 1000);

    return () => clearInterval(interval);
  }, [state.connectedAt]);

  return (
    <Card>
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between gap-4">
          <CardTitle className="text-lg font-semibold" data-testid="title-bot-status">
            Bot Status
          </CardTitle>
          <StatusIndicator status={state.status} showLabel />
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {state.serverInfo && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Globe className="h-4 w-4 flex-shrink-0" />
            <span className="truncate" data-testid="text-server-info">
              {state.serverInfo.host}:{state.serverInfo.port}
            </span>
          </div>
        )}

        {isConnecting && (
          <div className="space-y-3">
            <Skeleton className="h-4 w-32" data-testid="skeleton-connecting" />
            <Skeleton className="h-2 w-full" />
            <Skeleton className="h-2 w-full" />
          </div>
        )}

        {isConnected && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Clock className="h-4 w-4 flex-shrink-0" />
            <span data-testid="text-uptime">Uptime: {uptime}</span>
          </div>
        )}

        {(isConnected || state.status === "disconnected") && (
          <div className="space-y-3 pt-2">
            <div className="space-y-1.5">
              <div className="flex items-center justify-between gap-2 text-sm">
                <div className="flex items-center gap-2">
                  <Heart className="h-4 w-4 text-status-busy flex-shrink-0" />
                  <span>Health</span>
                </div>
                <span className="font-mono text-xs" data-testid="text-health">
                  {state.health.toFixed(1)}/20
                </span>
              </div>
              <Progress 
                value={healthPercent} 
                className="h-2"
                data-testid="progress-health"
              />
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center justify-between gap-2 text-sm">
                <div className="flex items-center gap-2">
                  <Drumstick className="h-4 w-4 text-status-away flex-shrink-0" />
                  <span>Hunger</span>
                </div>
                <span className="font-mono text-xs" data-testid="text-food">
                  {state.food}/20
                </span>
              </div>
              <Progress 
                value={foodPercent} 
                className="h-2"
                data-testid="progress-food"
              />
            </div>
          </div>
        )}

        {isConnected && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <div className="rounded-md bg-muted/50 p-3">
              <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
                <MapPin className="h-3 w-3 flex-shrink-0" />
                Position
              </div>
              <p className="font-mono text-sm truncate" data-testid="text-position">
                {formatPosition(state.position)}
              </p>
            </div>

            <div className="rounded-md bg-muted/50 p-3">
              <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
                <Gamepad2 className="h-3 w-3 flex-shrink-0" />
                Game Mode
              </div>
              <p className="text-sm capitalize" data-testid="text-gamemode">
                {state.gameMode || "Unknown"}
              </p>
            </div>
          </div>
        )}

        {isConnected && state.dimension && (
          <div className="rounded-md bg-muted/50 p-3">
            <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
              <Globe className="h-3 w-3 flex-shrink-0" />
              Dimension
            </div>
            <p className="text-sm" data-testid="text-dimension">
              {formatDimension(state.dimension)}
            </p>
          </div>
        )}

        {state.error && (
          <div className="rounded-md bg-destructive/10 border border-destructive/20 p-3">
            <div className="flex items-start gap-2">
              <AlertCircle className="h-4 w-4 text-destructive flex-shrink-0 mt-0.5" />
              <p className="text-sm text-destructive" data-testid="text-error">
                {state.error}
              </p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
