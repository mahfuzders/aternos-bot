import { useEffect, useRef, useState } from "react";
import { Send, Trash2, ArrowDown, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import type { ChatMessage, BotStatus } from "@shared/schema";

interface ChatLogProps {
  messages: ChatMessage[];
  status: BotStatus;
  onSendMessage: (message: string) => void;
  onClearChat: () => void;
}

function formatTimestamp(timestamp: number): string {
  const date = new Date(timestamp);
  return date.toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });
}

function getMessageStyle(type: ChatMessage["type"]): string {
  switch (type) {
    case "chat":
      return "text-foreground";
    case "whisper":
      return "text-purple-400 dark:text-purple-300";
    case "system":
      return "text-muted-foreground italic";
    case "action":
      return "text-status-away italic";
    case "bot":
      return "text-primary";
    default:
      return "text-foreground";
  }
}

export function ChatLog({ messages, status, onSendMessage, onClearChat }: ChatLogProps) {
  const [inputValue, setInputValue] = useState("");
  const [isAutoScroll, setIsAutoScroll] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);
  const viewportRef = useRef<HTMLDivElement>(null);
  
  const isDisabled = status !== "connected";

  useEffect(() => {
    if (isAutoScroll && viewportRef.current) {
      viewportRef.current.scrollTop = viewportRef.current.scrollHeight;
    }
  }, [messages, isAutoScroll]);

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const target = e.target as HTMLDivElement;
    const isAtBottom = target.scrollHeight - target.scrollTop - target.clientHeight < 50;
    setIsAutoScroll(isAtBottom);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputValue.trim() && !isDisabled) {
      onSendMessage(inputValue.trim());
      setInputValue("");
    }
  };

  const scrollToBottom = () => {
    if (viewportRef.current) {
      viewportRef.current.scrollTop = viewportRef.current.scrollHeight;
      setIsAutoScroll(true);
    }
  };

  return (
    <Card className="flex flex-col h-full min-h-[400px]">
      <CardHeader className="pb-4 flex-shrink-0">
        <div className="flex items-center justify-between gap-4">
          <CardTitle className="text-lg font-semibold flex items-center gap-2">
            <MessageSquare className="h-5 w-5" />
            Chat Log
          </CardTitle>
          <div className="flex items-center gap-2">
            {messages.length > 0 && (
              <Button
                variant="ghost"
                size="icon"
                onClick={onClearChat}
                data-testid="button-clear-chat"
                title="Clear chat history"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col min-h-0 pb-4">
        <div className="relative flex-1 min-h-0">
          <ScrollArea 
            className="h-full rounded-md bg-muted/30 border"
            ref={scrollRef}
          >
            <div 
              ref={viewportRef}
              onScroll={handleScroll}
              className="h-80 md:h-96 overflow-y-auto p-3 font-mono text-sm"
              data-testid="container-chat-messages"
            >
              {messages.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-muted-foreground gap-2">
                  <MessageSquare className="h-8 w-8 opacity-50" />
                  <p className="text-sm" data-testid="text-empty-chat">
                    {isDisabled ? "Connect to a server to see chat" : "No messages yet"}
                  </p>
                </div>
              ) : (
                <div className="space-y-1">
                  {messages.map((msg) => (
                    <div
                      key={msg.id}
                      className={cn("break-words leading-relaxed", getMessageStyle(msg.type))}
                      data-testid={`chat-message-${msg.id}`}
                    >
                      <span className="text-muted-foreground text-xs mr-2">
                        [{formatTimestamp(msg.timestamp)}]
                      </span>
                      {msg.username && (
                        <span className="font-semibold mr-1">
                          {msg.type === "whisper" && "[Whisper] "}
                          {msg.username}:
                        </span>
                      )}
                      <span>{msg.content}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </ScrollArea>
          
          {!isAutoScroll && messages.length > 0 && (
            <Button
              variant="secondary"
              size="sm"
              className="absolute bottom-3 right-3"
              onClick={scrollToBottom}
              data-testid="button-scroll-to-bottom"
            >
              <ArrowDown className="h-4 w-4 mr-1" />
              New messages
            </Button>
          )}
        </div>

        <form onSubmit={handleSubmit} className="flex gap-2 mt-3 flex-shrink-0">
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder={isDisabled ? "Connect to send messages" : "Type a message..."}
            disabled={isDisabled}
            maxLength={256}
            className="flex-1 font-mono"
            data-testid="input-chat-message"
          />
          <Button 
            type="submit" 
            disabled={isDisabled || !inputValue.trim()}
            data-testid="button-send-chat"
          >
            <Send className="h-4 w-4" />
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
