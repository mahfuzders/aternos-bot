import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Play, Square, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { botConfigSchema, type BotConfig, type BotStatus } from "@shared/schema";

interface ConnectionFormProps {
  status: BotStatus;
  onConnect: (config: BotConfig) => void;
  onDisconnect: () => void;
}

const MINECRAFT_VERSIONS = [
  { value: "1.20.4", label: "1.20.4 (Latest)" },
  { value: "1.20.2", label: "1.20.2" },
  { value: "1.20.1", label: "1.20.1" },
  { value: "1.19.4", label: "1.19.4" },
  { value: "1.18.2", label: "1.18.2" },
  { value: "1.16.5", label: "1.16.5" },
  { value: "1.12.2", label: "1.12.2" },
];

export function ConnectionForm({ status, onConnect, onDisconnect }: ConnectionFormProps) {
  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm<BotConfig>({
    resolver: zodResolver(botConfigSchema),
    defaultValues: {
      host: "",
      port: 25565,
      username: "",
      version: "1.20.4",
    },
  });

  const isConnected = status === "connected";
  const isConnecting = status === "connecting";
  const isDisabled = isConnected || isConnecting;

  const onSubmit = (data: BotConfig) => {
    onConnect(data);
  };

  const version = watch("version");

  return (
    <Card>
      <CardHeader className="pb-4">
        <CardTitle className="text-lg font-semibold">Server Connection</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="host">Server Address</Label>
            <Input
              id="host"
              placeholder="play.example.com"
              disabled={isDisabled}
              data-testid="input-server-host"
              {...register("host")}
            />
            {errors.host && (
              <p className="text-xs text-destructive" data-testid="error-host">
                {errors.host.message}
              </p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="port">Port</Label>
              <Input
                id="port"
                type="number"
                placeholder="25565"
                disabled={isDisabled}
                data-testid="input-server-port"
                {...register("port", { valueAsNumber: true })}
              />
              {errors.port && (
                <p className="text-xs text-destructive" data-testid="error-port">
                  {errors.port.message}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="version">Version</Label>
              <Select
                value={version}
                onValueChange={(v) => setValue("version", v)}
                disabled={isDisabled}
              >
                <SelectTrigger id="version" data-testid="select-version">
                  <SelectValue placeholder="Select version" />
                </SelectTrigger>
                <SelectContent>
                  {MINECRAFT_VERSIONS.map((v) => (
                    <SelectItem key={v.value} value={v.value}>
                      {v.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="username">Bot Username</Label>
            <Input
              id="username"
              placeholder="MinecraftBot"
              maxLength={16}
              disabled={isDisabled}
              data-testid="input-username"
              {...register("username")}
            />
            {errors.username && (
              <p className="text-xs text-destructive" data-testid="error-username">
                {errors.username.message}
              </p>
            )}
          </div>

          <div className="pt-2">
            {isConnected ? (
              <Button
                type="button"
                variant="destructive"
                className="w-full"
                onClick={onDisconnect}
                data-testid="button-disconnect"
              >
                <Square className="mr-2 h-4 w-4" />
                Disconnect
              </Button>
            ) : (
              <Button
                type="submit"
                className="w-full"
                disabled={isConnecting}
                data-testid="button-connect"
              >
                {isConnecting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Connecting...
                  </>
                ) : (
                  <>
                    <Play className="mr-2 h-4 w-4" />
                    Connect
                  </>
                )}
              </Button>
            )}
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
