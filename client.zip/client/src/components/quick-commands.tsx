import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { BotStatus } from "@shared/schema";

interface QuickCommandsProps {
  status: BotStatus;
  onSendCommand: (command: string) => void;
}

const quickCommands = [
  { label: "/help", command: "/help" },
  { label: "/spawn", command: "/spawn" },
  { label: "/home", command: "/home" },
  { label: "/tpa", command: "/tpa " },
  { label: "/msg", command: "/msg " },
  { label: "/list", command: "/list" },
];

export function QuickCommands({ status, onSendCommand }: QuickCommandsProps) {
  const isDisabled = status !== "connected";

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-semibold">Quick Commands</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-2">
          {quickCommands.map((cmd) => (
            <Badge
              key={cmd.label}
              variant="secondary"
              className={!isDisabled ? "cursor-pointer" : "opacity-50 cursor-not-allowed"}
              onClick={() => !isDisabled && onSendCommand(cmd.command)}
              data-testid={`badge-quick-command-${cmd.label.replace("/", "")}`}
            >
              {cmd.label}
            </Badge>
          ))}
        </div>
        {isDisabled && (
          <p className="text-xs text-muted-foreground mt-3">
            Connect to use quick commands
          </p>
        )}
      </CardContent>
    </Card>
  );
}
