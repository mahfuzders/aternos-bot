import { useEffect, useState } from "react";
import { Bot, Settings, MessageSquare, Gamepad2 } from "lucide-react";
import { useWebSocket } from "@/hooks/use-websocket";
import { ConnectionForm } from "@/components/connection-form";
import { BotStats } from "@/components/bot-stats";
import { CommandPanel } from "@/components/command-panel";
import { ChatLog } from "@/components/chat-log";
import { QuickCommands } from "@/components/quick-commands";
import { ThemeToggle } from "@/components/theme-toggle";
import { StatusIndicator } from "@/components/status-indicator";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Separator } from "@/components/ui/separator";
import type { BotCommandType, BotConfig } from "@shared/schema";

type ActiveTab = "overview" | "controls" | "chat" | "settings";

const navItems = [
  { id: "overview" as ActiveTab, label: "Overview", icon: Bot },
  { id: "controls" as ActiveTab, label: "Controls", icon: Gamepad2 },
  { id: "chat" as ActiveTab, label: "Chat", icon: MessageSquare },
  { id: "settings" as ActiveTab, label: "Settings", icon: Settings },
];

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState<ActiveTab>("overview");
  const [, setUptimeRefresh] = useState(0);
  const { 
    isConnected: wsConnected, 
    botState, 
    chatMessages, 
    connect, 
    disconnect, 
    sendCommand, 
    sendChat,
    clearChat 
  } = useWebSocket();

  useEffect(() => {
    const interval = setInterval(() => {
      if (botState.connectedAt) {
        setUptimeRefresh((n) => n + 1);
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [botState.connectedAt]);

  const handleConnect = (config: BotConfig) => {
    connect(config);
  };

  const handleDisconnect = () => {
    disconnect();
  };

  const handleCommand = (type: BotCommandType) => {
    sendCommand(type);
  };

  const handleSendChat = (message: string) => {
    sendChat(message);
  };

  const sidebarStyle = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3.5rem",
  } as React.CSSProperties;

  return (
    <SidebarProvider style={sidebarStyle}>
      <div className="flex h-screen w-full bg-background">
        <Sidebar>
          <SidebarHeader className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary">
                <Bot className="h-6 w-6 text-primary-foreground" />
              </div>
              <div className="flex flex-col">
                <span className="font-semibold text-sm">Minecraft Bot</span>
                <StatusIndicator status={botState.status} showLabel size="sm" />
              </div>
            </div>
          </SidebarHeader>
          <Separator />
          <SidebarContent>
            <SidebarGroup>
              <SidebarGroupLabel>Navigation</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {navItems.map((item) => (
                    <SidebarMenuItem key={item.id}>
                      <SidebarMenuButton
                        isActive={activeTab === item.id}
                        onClick={() => setActiveTab(item.id)}
                        data-testid={`nav-${item.id}`}
                      >
                        <item.icon className="h-4 w-4" />
                        <span>{item.label}</span>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>

            {!wsConnected && (
              <SidebarGroup>
                <SidebarGroupContent>
                  <div className="px-3 py-2">
                    <div className="rounded-md bg-destructive/10 border border-destructive/20 p-3">
                      <p className="text-xs text-destructive">
                        Dashboard disconnected. Reconnecting...
                      </p>
                    </div>
                  </div>
                </SidebarGroupContent>
              </SidebarGroup>
            )}
          </SidebarContent>
        </Sidebar>

        <div className="flex flex-col flex-1 min-w-0">
          <header className="flex items-center justify-between gap-4 border-b px-4 h-14 flex-shrink-0">
            <div className="flex items-center gap-4">
              <SidebarTrigger data-testid="button-sidebar-toggle" />
              <h1 className="text-lg font-semibold capitalize">
                {activeTab === "overview" ? "Dashboard" : activeTab}
              </h1>
            </div>
            <ThemeToggle />
          </header>

          <main className="flex-1 overflow-auto p-4 md:p-6">
            {activeTab === "overview" && (
              <div className="grid gap-4 md:gap-6 lg:grid-cols-2">
                <div className="space-y-4 md:space-y-6">
                  <BotStats state={botState} />
                  <QuickCommands status={botState.status} onSendCommand={handleSendChat} />
                </div>
                <div className="lg:h-full">
                  <ChatLog 
                    messages={chatMessages} 
                    status={botState.status}
                    onSendMessage={handleSendChat}
                    onClearChat={clearChat}
                  />
                </div>
              </div>
            )}

            {activeTab === "controls" && (
              <div className="max-w-md mx-auto">
                <CommandPanel status={botState.status} onCommand={handleCommand} />
              </div>
            )}

            {activeTab === "chat" && (
              <div className="h-full max-w-4xl mx-auto">
                <ChatLog 
                  messages={chatMessages} 
                  status={botState.status}
                  onSendMessage={handleSendChat}
                  onClearChat={clearChat}
                />
              </div>
            )}

            {activeTab === "settings" && (
              <div className="max-w-md mx-auto space-y-6">
                <ConnectionForm
                  status={botState.status}
                  onConnect={handleConnect}
                  onDisconnect={handleDisconnect}
                />
              </div>
            )}
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
