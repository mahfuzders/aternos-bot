import type { BotConfig } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getSavedConfigs(): Promise<BotConfig[]>;
  saveConfig(config: BotConfig): Promise<BotConfig & { id: string }>;
  deleteConfig(id: string): Promise<void>;
}

export class MemStorage implements IStorage {
  private configs: Map<string, BotConfig & { id: string }>;

  constructor() {
    this.configs = new Map();
  }

  async getSavedConfigs(): Promise<BotConfig[]> {
    return Array.from(this.configs.values());
  }

  async saveConfig(config: BotConfig): Promise<BotConfig & { id: string }> {
    const id = randomUUID();
    const savedConfig = { ...config, id };
    this.configs.set(id, savedConfig);
    return savedConfig;
  }

  async deleteConfig(id: string): Promise<void> {
    this.configs.delete(id);
  }
}

export const storage = new MemStorage();
