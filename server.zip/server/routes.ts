import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { botManager } from "./bot-manager";
import { botConfigSchema } from "@shared/schema";
import type { WSMessage, BotConfig, BotCommandType } from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  const wss = new WebSocketServer({ server: httpServer, path: "/ws" });

  const clients = new Set<WebSocket>();

  const broadcast = (message: WSMessage) => {
    const data = JSON.stringify(message);
    clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(data);
      }
    });
  };

  botManager.setCallbacks({
    onStateChange: (state) => {
      broadcast({ type: "bot_state", payload: state });
    },
    onChatMessage: (message) => {
      broadcast({ type: "chat_message", payload: message });
    },
  });

  wss.on("connection", (ws, req) => {
    const origin = req.headers.origin;
    const host = req.headers.host;
    
    if (origin && host && !origin.includes(host.split(":")[0])) {
      ws.close(1008, "Invalid origin");
      return;
    }

    clients.add(ws);

    ws.send(JSON.stringify({ type: "bot_state", payload: botManager.getState() }));
    ws.send(JSON.stringify({ type: "chat_history", payload: botManager.getChatHistory() }));

    ws.on("message", async (data) => {
      try {
        const message: WSMessage = JSON.parse(data.toString());

        switch (message.type) {
          case "connect": {
            const parseResult = botConfigSchema.safeParse(message.payload);
            if (!parseResult.success) {
              ws.send(JSON.stringify({ type: "error", payload: "Invalid configuration" }));
              return;
            }
            await botManager.connect(parseResult.data as BotConfig);
            break;
          }
          case "disconnect": {
            await botManager.disconnect();
            break;
          }
          case "command": {
            const commandPayload = message.payload as { type: BotCommandType; payload?: unknown };
            if (!commandPayload || !commandPayload.type) {
              ws.send(JSON.stringify({ type: "error", payload: "Invalid command" }));
              return;
            }
            botManager.executeCommand(
              commandPayload.type, 
              commandPayload.payload as string | { x: number; y: number; z: number } | undefined
            );
            break;
          }
          case "clear_chat": {
            botManager.clearChatHistory();
            broadcast({ type: "chat_history", payload: [] });
            break;
          }
        }
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        ws.send(JSON.stringify({ type: "error", payload: errorMessage }));
      }
    });

    ws.on("close", () => {
      clients.delete(ws);
    });

    ws.on("error", () => {
      clients.delete(ws);
    });
  });

  app.get("/api/bot/status", (_req, res) => {
    res.json({ success: true, data: botManager.getState() });
  });

  app.get("/api/bot/chat", (_req, res) => {
    res.json({ success: true, data: botManager.getChatHistory() });
  });

  return httpServer;
}
