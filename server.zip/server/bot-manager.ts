import mineflayer from "mineflayer";
import { randomUUID } from "crypto";
import type { BotState, ChatMessage, BotCommandType, BotConfig } from "@shared/schema";

type BotEventCallback = {
  onStateChange: (state: BotState) => void;
  onChatMessage: (message: ChatMessage) => void;
};

class BotManager {
  private bot: mineflayer.Bot | null = null;
  private callbacks: BotEventCallback | null = null;
  private chatHistory: ChatMessage[] = [];
  private reconnectTimeout: NodeJS.Timeout | null = null;
  private currentConfig: BotConfig | null = null;
  private shouldReconnect: boolean = false;
  private connectionAttempts: number = 0;
  private maxConnectionAttempts: number = 5;

  private state: BotState = {
    status: "disconnected",
    health: 20,
    food: 20,
    position: null,
    gameMode: null,
    dimension: null,
    serverInfo: null,
    connectedAt: null,
    error: null,
  };

  setCallbacks(callbacks: BotEventCallback) {
    this.callbacks = callbacks;
  }

  getState(): BotState {
    return { ...this.state };
  }

  getChatHistory(): ChatMessage[] {
    return [...this.chatHistory];
  }

  clearChatHistory() {
    this.chatHistory = [];
  }

  private updateState(partial: Partial<BotState>) {
    this.state = { ...this.state, ...partial };
    this.callbacks?.onStateChange(this.state);
  }

  private addChatMessage(type: ChatMessage["type"], content: string, username: string | null = null) {
    const message: ChatMessage = {
      id: randomUUID(),
      timestamp: Date.now(),
      type,
      username,
      content,
    };
    this.chatHistory.push(message);
    if (this.chatHistory.length > 200) {
      this.chatHistory = this.chatHistory.slice(-200);
    }
    this.callbacks?.onChatMessage(message);
  }

  async connect(config: BotConfig): Promise<void> {
    if (this.bot) {
      await this.disconnect();
    }

    this.currentConfig = config;
    this.shouldReconnect = true;
    this.connectionAttempts++;
    
    this.updateState({
      status: "connecting",
      error: null,
      serverInfo: { host: config.host, port: config.port },
    });

    this.addChatMessage("bot", `Connecting to ${config.host}:${config.port} (attempt ${this.connectionAttempts})...`);

    try {
      this.bot = mineflayer.createBot({
        host: config.host,
        port: config.port,
        username: config.username,
        version: config.version || undefined,
        auth: "offline",
        hideErrors: false,
      });

      this.setupBotEvents();
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      this.updateState({
        status: "error",
        error: errorMessage,
      });
      this.addChatMessage("system", `Connection failed: ${errorMessage}`);
      this.scheduleReconnect();
    }
  }

  private scheduleReconnect() {
    if (!this.shouldReconnect || !this.currentConfig) {
      return;
    }

    if (this.connectionAttempts >= this.maxConnectionAttempts) {
      this.addChatMessage("system", `Max reconnection attempts (${this.maxConnectionAttempts}) reached. Giving up.`);
      this.updateState({
        status: "error",
        error: "Max reconnection attempts reached",
      });
      this.shouldReconnect = false;
      return;
    }

    const delay = Math.min(5000 * this.connectionAttempts, 30000);
    this.addChatMessage("bot", `Reconnecting in ${delay / 1000} seconds...`);
    
    if (this.reconnectTimeout) {
      clearTimeout(this.reconnectTimeout);
    }
    
    this.reconnectTimeout = setTimeout(() => {
      if (this.shouldReconnect && this.currentConfig) {
        this.connect(this.currentConfig);
      }
    }, delay);
  }

  private setupBotEvents() {
    if (!this.bot) return;

    this.bot.once("login", () => {
      this.addChatMessage("bot", "Login successful, waiting for spawn...");
    });

    this.bot.once("spawn", () => {
      this.connectionAttempts = 0;
      this.updateState({
        status: "connected",
        connectedAt: Date.now(),
        error: null,
        health: this.bot?.health ?? 20,
        food: this.bot?.food ?? 20,
        position: this.bot?.entity?.position ? {
          x: this.bot.entity.position.x,
          y: this.bot.entity.position.y,
          z: this.bot.entity.position.z,
        } : null,
        gameMode: this.bot?.game?.gameMode ?? null,
        dimension: this.bot?.game?.dimension ?? null,
      });
      this.addChatMessage("bot", "Successfully connected and spawned!");
    });

    this.bot.on("health", () => {
      if (this.state.status === "connected") {
        this.updateState({
          health: this.bot?.health ?? 20,
          food: this.bot?.food ?? 20,
        });
      }
    });

    this.bot.on("move", () => {
      if (this.bot?.entity?.position && this.state.status === "connected") {
        this.updateState({
          position: {
            x: this.bot.entity.position.x,
            y: this.bot.entity.position.y,
            z: this.bot.entity.position.z,
          },
        });
      }
    });

    this.bot.on("game", () => {
      if (this.state.status === "connected") {
        this.updateState({
          gameMode: this.bot?.game?.gameMode ?? null,
          dimension: this.bot?.game?.dimension ?? null,
        });
      }
    });

    this.bot.on("chat", (username, message) => {
      if (username === this.bot?.username) return;
      this.addChatMessage("chat", message, username);
    });

    this.bot.on("whisper", (username, message) => {
      this.addChatMessage("whisper", message, username);
    });

    this.bot.on("message", (jsonMsg) => {
      const msg = jsonMsg.toString();
      if (msg && !msg.startsWith("<") && !msg.includes("whispers") && msg.trim().length > 0) {
        this.addChatMessage("system", msg);
      }
    });

    this.bot.on("kicked", (reason) => {
      const reasonText = typeof reason === "string" ? reason : JSON.stringify(reason);
      this.addChatMessage("system", `Kicked: ${reasonText}`);
      this.updateState({
        status: "disconnected",
        error: `Kicked: ${reasonText}`,
        connectedAt: null,
      });
      this.bot = null;
      this.scheduleReconnect();
    });

    this.bot.on("error", (error) => {
      this.addChatMessage("system", `Error: ${error.message}`);
      if (this.state.status === "connecting") {
        this.updateState({
          status: "error",
          error: error.message,
        });
        this.bot = null;
        this.scheduleReconnect();
      }
    });

    this.bot.on("end", (reason) => {
      if (this.state.status !== "disconnected") {
        this.addChatMessage("system", `Disconnected: ${reason || "Connection closed"}`);
        this.updateState({
          status: "disconnected",
          connectedAt: null,
        });
      }
      this.bot = null;

      if (this.shouldReconnect && reason !== "disconnect.quitting") {
        this.scheduleReconnect();
      }
    });

    this.bot.on("death", () => {
      this.addChatMessage("system", "Bot died!");
    });

    this.bot.on("respawn", () => {
      this.addChatMessage("bot", "Respawned!");
    });
  }

  async disconnect(): Promise<void> {
    this.shouldReconnect = false;
    this.connectionAttempts = 0;
    
    if (this.reconnectTimeout) {
      clearTimeout(this.reconnectTimeout);
      this.reconnectTimeout = null;
    }
    this.currentConfig = null;
    
    if (this.bot) {
      this.addChatMessage("bot", "Disconnecting...");
      try {
        this.bot.quit("User disconnected");
      } catch {
        // Ignore quit errors
      }
      this.bot = null;
    }
    
    this.updateState({
      status: "disconnected",
      connectedAt: null,
      serverInfo: null,
      error: null,
    });
  }

  executeCommand(type: BotCommandType, payload?: string | { x: number; y: number; z: number }) {
    if (!this.bot || this.state.status !== "connected") {
      return false;
    }

    try {
      switch (type) {
        case "move_forward":
          this.bot.setControlState("forward", true);
          setTimeout(() => this.bot?.setControlState("forward", false), 500);
          break;
        case "move_back":
          this.bot.setControlState("back", true);
          setTimeout(() => this.bot?.setControlState("back", false), 500);
          break;
        case "move_left":
          this.bot.setControlState("left", true);
          setTimeout(() => this.bot?.setControlState("left", false), 500);
          break;
        case "move_right":
          this.bot.setControlState("right", true);
          setTimeout(() => this.bot?.setControlState("right", false), 500);
          break;
        case "jump":
          this.bot.setControlState("jump", true);
          setTimeout(() => this.bot?.setControlState("jump", false), 500);
          break;
        case "sneak":
          const sneaking = this.bot.getControlState("sneak");
          this.bot.setControlState("sneak", !sneaking);
          this.addChatMessage("bot", sneaking ? "Stopped sneaking" : "Started sneaking");
          break;
        case "sprint":
          const sprinting = this.bot.getControlState("sprint");
          this.bot.setControlState("sprint", !sprinting);
          this.addChatMessage("bot", sprinting ? "Stopped sprinting" : "Started sprinting");
          break;
        case "stop":
          this.bot.clearControlStates();
          this.addChatMessage("bot", "Stopped all movement");
          break;
        case "attack":
          const nearestEntity = this.bot.nearestEntity((entity) => {
            if (!entity) return false;
            return entity.type === "mob" || entity.type === "hostile" || entity.type === "player";
          });
          if (nearestEntity) {
            this.bot.attack(nearestEntity);
            this.addChatMessage("bot", `Attacking ${nearestEntity.name || "entity"}`);
          } else {
            this.addChatMessage("bot", "No entity nearby to attack");
          }
          break;
        case "use":
          this.bot.activateItem();
          this.addChatMessage("bot", "Used held item");
          break;
        case "chat":
          if (typeof payload === "string" && payload.trim()) {
            this.bot.chat(payload);
            this.addChatMessage("bot", payload, this.bot.username);
          }
          break;
        case "look_at":
          if (payload && typeof payload === "object" && "x" in payload && "y" in payload && "z" in payload) {
            const target = { x: payload.x, y: payload.y, z: payload.z };
            this.bot.lookAt(target as unknown as mineflayer.Vec3);
            this.addChatMessage("bot", `Looking at ${target.x}, ${target.y}, ${target.z}`);
          }
          break;
        case "disconnect":
          this.disconnect();
          break;
        default:
          return false;
      }
      return true;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Command failed";
      this.addChatMessage("system", `Command error: ${errorMessage}`);
      return false;
    }
  }
}

export const botManager = new BotManager();
